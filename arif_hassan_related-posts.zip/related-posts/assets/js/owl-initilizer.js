jQuery(document).ready(function () {
  jQuery(".owl-carousel").owlCarousel({
    loop: true,
    nav: true,
    center: true,
    navigation: true,
    autoplay: false,
    autoplayHoverPause: true,
  });
});
